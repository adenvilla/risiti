/* Risiti service worker: cache-first app shell so the app works offline. */
const CACHE = 'risiti-shell-v7';
const SHELL = ['./', 'index.html', 'css/styles.css', 'manifest.webmanifest', 'assets/logo.png', 'assets/icon-192.png',
  'assets/favicon-32.png', 'assets/apple-touch-icon.png',
  'js/config.js', 'js/icons.js', 'js/utils.js', 'js/store.js', 'js/ui/components.js', 'js/ui/intro.js',
  'js/ui/onboarding.js', 'js/ui/main.js', 'js/ui/sheets.js', 'js/actions.js', 'js/app.js'];

self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', (e) => e.waitUntil(
  caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request).then((res) => {
    if (res.ok && new URL(e.request.url).origin === location.origin) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return res;
  }).catch(() => caches.match('index.html'))));
});
