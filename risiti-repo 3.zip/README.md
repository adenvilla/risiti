# Risiti — Smart receipts for Kenyan shops

A mobile-first app for receipts, M-Pesa payments and stock in small shops. Runs entirely in the browser — no build step, no backend (payments and OTP are simulated).

## Enrollment in three screens
1. **Welcome** — one button: *Get started*. Optional links: *See how it works* (4-slide tour) and *Try demo shop*.
2. **Phone** — enter a number; the code is read and verified automatically (the demo simulates Android SMS auto-read). No password, no Verify button.
3. **Shop** — shop name + one tap on what you sell. A live receipt preview updates as you type, and popular items for that shop type are pre-loaded so the first sale is one tap.

Everything else lives in a **Home checklist** with a progress ring: first sale → Till/Paybill → review products → logo. Nothing blocks the user from selling.

## Features
- **Instant receipts** — share by WhatsApp, SMS, copy or QR code. Receipts render as paper with a scalloped edge, a gold seal and a PAID stamp.
- **M-Pesa flow (simulated)** — STK push, pending → paid and an M-Pesa reference.
- **Smart stock** — optional per-product tracking, low/out alerts, stock drops on every sale; the cart can't exceed what's on the shelf.
- **Daily summary** — revenue, M-Pesa vs cash, pending, top seller, restock list; share to WhatsApp.
- **History, customers, CSV export, VAT (16%), logo upload, installable PWA.**

## Design language — "Heritage luxury"
Dark emerald chrome (header, hero, nav accents) over warm ivory, with brushed-gold foil used sparingly for the primary actions. Headings and amounts use the Fraunces serif; body text uses DM Sans. The woven diamond motif from the logo repeats as a pattern, a border strip and gold hairline frames. All tokens live at the top of `css/styles.css`.

## Run it
```bash
git clone <this repo> && cd risiti
python3 -m http.server 8080   # then open http://localhost:8080
```
Opening `index.html` directly also works (the service worker only registers over http/https).

## Project structure
```
index.html            App shell, splash and script load order
css/styles.css        Design tokens, components, screens, welcome/tour, animations
js/config.js          Constants, shop types and starter products
js/icons.js           SVG icon set
js/utils.js           Safe html`` templating, formatting, dates, phones, sale maths
js/store.js           State (S), UI state (U), demo/blank state, selectors, mutations
js/ui/*.js            Views: components, tour, onboarding, main tabs, sheets
js/actions.js         Click handlers keyed by data-a attributes
js/app.js             Render loop, delegated events, timers, service worker
assets/               Brand logo, app icons, social preview image
sw.js                 Cache-first service worker
```

## Architecture notes
- **Safe by default:** views use the `html` tagged template, which escapes every interpolated value unless it is a `Raw` fragment.
- **One-way data flow:** actions change `S` (persisted) or `U` (transient) and call `render()`.
- **Event delegation:** one click listener dispatches to `Actions[data-a]`; inputs bind via `data-i="S.shop.name"` paths.
- **Real shops start empty;** demo data is only loaded by *Try demo shop*.
- **Persistence:** `localStorage` under `risiti.v5`.

## From demo to product
| Demo today | Production plan |
|---|---|
| Simulated SMS auto-read | Real phone OTP (Supabase Auth or Africa's Talking) + WebOTP API |
| Timed STK push | Safaricom Daraja STK Push + callback-confirmed payments |
| `localStorage` | Database with per-shop row-level security |
| No tax integration | KRA eTIMS invoicing for VAT-registered shops |

## License
MIT
